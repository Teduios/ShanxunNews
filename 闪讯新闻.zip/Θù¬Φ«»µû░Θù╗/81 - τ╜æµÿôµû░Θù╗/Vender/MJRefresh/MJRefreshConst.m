//
//  MJRefreshConst.m
//  MJRefresh
//
//  Created by mj on 14-1-3.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

const CGFloat MJRefreshViewHeight = 64.0;
const CGFloat MJRefreshFastAnimationDuration = 0.25;
const CGFloat MJRefreshSlowAnimationDuration = 0.4;

NSString *const MJRefreshFooterPullToRefresh = @"上拉可以加载更多数据";
NSString *const MJRefreshFooterReleaseToRefresh = @"松开立即加载更多数据";
NSString *const MJRefreshFooterRefreshing = @"★闪讯新闻★正在帮你加载数据...";

NSString *const MJRefreshHeaderPullToRefresh = @"不要再犹豫";
NSString *const MJRefreshHeaderReleaseToRefresh = @"松开获得数据！！";
NSString *const MJRefreshHeaderRefreshing = @"★闪讯新闻★正在帮你加载数据...";
NSString *const MJRefreshHeaderTimeKey = @"MJRefreshHeaderView";

NSString *const MJRefreshContentOffset = @"contentOffset";
NSString *const MJRefreshContentSize = @"contentSize";