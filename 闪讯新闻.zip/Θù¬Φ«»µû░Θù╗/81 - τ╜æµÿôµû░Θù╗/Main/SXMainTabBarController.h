//
//  SXMainTabBarController.h
//  闪讯新闻
//
//  Created by 袁 帅帅 on 15/10/9.
//  Copyright (c) 2015年 yuanShauiShuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXMainTabBarController : UITabBarController

@end
