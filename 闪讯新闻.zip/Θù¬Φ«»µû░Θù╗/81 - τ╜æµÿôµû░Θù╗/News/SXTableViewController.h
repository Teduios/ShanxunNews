//
//  SXTableViewController.h
//  闪讯新闻
//
//  Created by 袁 帅帅 on 15-10-22.
//  Copyright (c) 2015年 yuanShuaiShuaiDante. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXTableViewController : UITableViewController

/**
 *  url端口
 */
@property(nonatomic,copy) NSString *urlString;

@property (nonatomic,assign) NSInteger index;


@end
